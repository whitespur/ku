1.配置好docker
2.配置好nvidia-container-toolkit
3.装好docker-compose
4.装好cron
先在物理机跑一遍kuczo
然后在docker-compose.yml目录执行compose.sh里面的指令，第一个是启动服务，第二个是扩展服务
之后再配置cron定时重启service就行了
docker-compose up -d
docker-compose scale kuzco-worker=15
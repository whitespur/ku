#!/bin/bash

# manage_workers.sh
# Usage: ./manage_workers.sh <number_of_workers> <start|restart|stop>

# Get the absolute path to the script
SCRIPT=$(readlink -f "$0")
SCRIPT_DIR=$(dirname "$SCRIPT")

# Name of the script to be called
WORKER_SCRIPT="manage_workers.sh"

# Number of workers to run and restart
WORKER_NUM=$1

# Command (start or restart)
CMD=$2

# Function to start workers
start_workers() {
    mkdir -p "$SCRIPT_DIR/log"
    for i in $(seq 1 $WORKER_NUM); do
        echo "Starting worker $i"
        nohup sudo kuzco worker start > "$SCRIPT_DIR/log/worker_$i.log" 2>&1 &
        sleep 10
    done
}

# Function to kill all workers
kill_workers() {
    pkill -f kuzco
}

case "$CMD" in
    start)
        # Start initial workers
        start_workers
        ;;
    restart)
        # Kill all existing workers
        kill_workers
        # Wait a little bit to make sure processes have been killed
        sleep 5
        # Start workers again
        start_workers
        ;;
    stop)
        kill_workers
        ;;
    *)
        echo "Unknown command: $CMD"
        echo "Usage: $WORKER_SCRIPT <number_of_workers> <start|restart|stop>"
        exit 1
        ;;
esac
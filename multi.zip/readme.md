1. Make sure you have executed 'kuzco init' and 'kuzco worker start'
2. cd your working directory
3. sudo sh manage_workers.sh <worker_num> <start|restart|stop>
4. log will save in working directory ./log/xxxx
5. use crontab to schedule the worker to restart very hour
sudo crontab -e
0 * * * * /bin/sh /path/to/manage_workers.sh <worker_num> restart